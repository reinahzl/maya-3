document.addEventListener('DOMContentLoaded', () => {
  const container = document.body;
  const semestres = [
    { nombre: '1er Semestre', materias: ['Constitucional', 'Personas', 'Ideas Político Jurídicas', 'Sociedad y Derecho', 'Historia del Derecho'] },
    { nombre: '2do Semestre', materias: ['Taller de Lectoescritura', 'Introducción al Fenómeno Jurídico', 'Introducción al D. Penal', 'Bienes', 'Informática Jurídica 1', 'Ciencia Política', 'Derechos Humanos'] }
    // Se agregan los demás semestres y materias...
  ];

  semestres.forEach((semestre, i) => {
    const col = document.createElement('div');
    col.style.display = 'flex';
    col.style.flexDirection = 'column';
    col.style.marginRight = '20px';

    const titulo = document.createElement('h3');
    titulo.textContent = semestre.nombre;
    col.appendChild(titulo);

    semestre.materias.forEach(materia => {
      const div = document.createElement('div');
      div.className = 'materia';
      div.textContent = materia;
      col.appendChild(div);
    });

    container.appendChild(col);
  });
});